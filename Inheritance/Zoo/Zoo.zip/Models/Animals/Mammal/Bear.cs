﻿namespace Zoo.Models.Animals.Mammal
{
    public class Bear : Mammal
    {
        public Bear(string name) : base(name)
        {
        }
    }
}

﻿namespace Zoo.Models.Animals.Reptile
{
    public class Snake : Reptile
    {
        public Snake(string name) : base(name)
        {
        }
    }
}

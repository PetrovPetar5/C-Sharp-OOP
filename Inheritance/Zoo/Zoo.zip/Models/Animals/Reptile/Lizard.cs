﻿namespace Zoo.Models.Animals.Reptile
{
    public class Lizard : Reptile
    {
        public Lizard(string name) : base(name)
        {
        }
    }
}

﻿namespace Telephony.Contracts
{
    public interface IBrowsable
    {
        public string Browse(string siteToVisit);
    }
}

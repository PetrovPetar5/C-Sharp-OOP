﻿namespace Zoo.Models.Animals.Reptile
{
    public abstract class Reptile : Animal
    {
        protected Reptile(string name) : base(name)
        {
        }
    }
}

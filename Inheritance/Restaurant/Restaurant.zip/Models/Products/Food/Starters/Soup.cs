﻿namespace Restaurant.Models.Products.Food.Starters
{
    public class Soup : Starter
    {
        public Soup(string name, decimal price, double grams) : base(name, price, grams)
        {
        }
    }
}

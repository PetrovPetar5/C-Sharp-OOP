﻿namespace PlayersAndMonsters.Models.Heroes.Knights
{
    public class Knight : Hero
    {
        public Knight(string userName, int level) : base(userName, level)
        {
        }
    }
}

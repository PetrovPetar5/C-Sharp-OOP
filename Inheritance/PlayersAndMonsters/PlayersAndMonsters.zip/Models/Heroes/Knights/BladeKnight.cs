﻿namespace PlayersAndMonsters.Models.Heroes.Knights
{
    public class BladeKnight : DarkKnight
    {
        public BladeKnight(string userName, int level) : base(userName, level)
        {
        }
    }
}

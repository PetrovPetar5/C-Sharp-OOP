﻿namespace PlayersAndMonsters.Models.Heroes.Wizards
{
    public class Wizard : Hero
    {
        public Wizard(string userName, int level) : base(userName, level)
        {
        }
    }
}

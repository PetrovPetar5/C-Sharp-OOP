﻿namespace PlayersAndMonsters.Models.Heroes.Elfs
{
    public class MuseElf : Elf
    {
        public MuseElf(string userName, int level) : base(userName, level)
        {
        }
    }
}

﻿namespace Telephony.Contracts
{
   public interface IPhonable
    {
        public string call(string numberToDial);
    }
}

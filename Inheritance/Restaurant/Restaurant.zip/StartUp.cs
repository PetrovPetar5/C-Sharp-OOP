﻿namespace Restaurant
{
    using System;
    public class StartUp
    {
        static void Main(string[] args)
        {
        }
    }
}

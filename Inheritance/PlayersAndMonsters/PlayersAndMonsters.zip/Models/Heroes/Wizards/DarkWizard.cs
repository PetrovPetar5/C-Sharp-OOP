﻿namespace PlayersAndMonsters.Models.Heroes.Wizards
{
    public class DarkWizard : Wizard
    {
        public DarkWizard(string userName, int level) : base(userName, level)
        {
        }
    }
}

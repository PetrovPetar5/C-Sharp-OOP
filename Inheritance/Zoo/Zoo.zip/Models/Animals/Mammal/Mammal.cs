﻿namespace Zoo.Models.Animals.Mammal
{
    public abstract class Mammal : Animal
    {
        protected Mammal(string name) : base(name)
        {
        }
    }
}

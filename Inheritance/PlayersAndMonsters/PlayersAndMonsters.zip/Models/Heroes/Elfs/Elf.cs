﻿namespace PlayersAndMonsters.Models.Heroes.Elfs
{
    public  class Elf : Hero
    {
        public Elf(string userName, int level) : base(userName, level)
        {
        }
    }
}


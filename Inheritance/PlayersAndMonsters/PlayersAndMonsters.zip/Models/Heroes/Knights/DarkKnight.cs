﻿namespace PlayersAndMonsters.Models.Heroes.Knights
{
    public class DarkKnight : Knight
    {
        public DarkKnight(string userName, int level) : base(userName, level)
        {
        }
    }
}
